## ---- eval=FALSE---------------------------------------------------------
#  library(omicplotR)
#  omicplotr.run()

## ---- eval=FALSE---------------------------------------------------------
#  data(otu_table)
#  data(metadata)

## ---- echo = FALSE, out.width='80%', fig.align='center', fig.cap="Example data. If taxonomy column introduced, it must use the column name 'taxonomy'."----
knitr::include_graphics("./example_data.png")

## ---- echo = FALSE, out.width='70%', fig.align='center', fig.cap="Example metadata file. Metadata maybe be numerical or categorical. Any blank spaces will be replaced as NA when importing the file."----
knitr::include_graphics("./example_metadata.png")

## ---- eval=FALSE---------------------------------------------------------
#  library(omicplotR)
#  omicplotr.run()

## ---- echo = FALSE, fig.align='center', fig.cap="Screenshot of input data page. Click on 'Example data' to access the provided datasets within the Shiny app"----
knitr::include_graphics("inputdata.png")

## ---- echo = FALSE, fig.align='center', fig.cap="Screen of coloured principal component analysis biplot. Steps to recreate this plot are lablled 1-4."----
knitr::include_graphics("col_PCA.png")

## ---- echo = FALSE, fig.align='center', out.width='50%', fig.cap="Pop-up generated from click 'Filter by metadata values'. Select a column an enter values from the column to re-plot only those values. They must match exactly. Filter can be reset or updated."----
knitr::include_graphics("metafilter.png")

## ---- echo = FALSE, fig.align='center', fig.cap="Screenshot of effect plots. Hovering over a feautre's point in the effect plot generates a stripchart to compare the relative abundances calculated by ALDEx2 for each sample."----
knitr::include_graphics("effect.png")

